departments = [
    {"id": 1, "name": "accounting"},
    {"id": 2, "name": "marketing"}
]

employees = [
    {"id": 1, "fio": "ivan petrov", "salary": 40, "id_accounting": 2},
    {"id": 2, "fio": "bob ivanov", "salary": 50, "id_accounting": 2},
    {"id": 3, "fio": "john don", "salary": 10, "id_accounting": 1}
]

def add_department(name):
    department_id = departments[-1]["id"] + 1
    departments.append({
        "id": department_id, 
        "name": name
    })

def add_employee(list_employee):
    employees_id = employees[-1]["id"] + 1
    employees.append({
        "id": employees_id,
        "fio": list_employee[0],
        "salary": list_employee[1],
        "id_accounting": list_employee[2]
    })


def change_departments_in_employee(data):
    index_employee = employees.index(*filter(lambda item: item['id'] == data[0], employees))
    if index_employee:
        employees[index_employee]["id_accounting"] = data[1]
