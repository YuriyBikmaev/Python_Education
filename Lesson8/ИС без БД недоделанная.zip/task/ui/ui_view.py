import models
import ui.ui_controller as controller


def menu():
    print()
    for key, item in controller.MENU_ACTIONS.items():
        print(key, item[0])
    result = int(input("Выберите пункт меню: "))
    print()
    return result


def show_departments():
    print_row_departments(models.departments[0].keys())
    for el in models.departments:
        print_row_departments(el.values())

def print_row_departments(dict_row):
    print("{: >5} {: >25}".format(*dict_row))


def show_employees():
    print_row_employees(models.employees[0].keys())
    for el in models.employees:
        print_row_employees(el.values())


def print_row_employees(dict_row):
    print("{: >5} {: >25} {: >10} {: >20}".format(*dict_row))

def input_department():
    return input("Название отдела: ")


def input_employee():
    result = []
    for el in models.employees[0].keys():
        if el == "id":
            continue
        else:
            result.append(input(f"Введите {el}: "))
    return result


def input_id_department():
    return int(input("Введите id отдела: "))

def input_id_employee():
    return int(input("Введите id сотрудника: "))


def show_employees_in_departments():
    id_department = input_id_department()
    print_row_employees(models.employees[0].keys())
    for el in models.employees:
        if el['id_accounting'] == id_department:
            print_row_employees(el.values())

def input_new_department_in_employee():
    return [input_id_employee(), input_id_department()]

