import ui.ui_view as view
import models

def run():
    menu_number = True
    while menu_number:
        menu_number = view.menu()
        input_data = MENU_ACTIONS[menu_number][1]()
        if input_data:
            MENU_ACTIONS[menu_number][2](input_data)


MENU_ACTIONS = {
    1: ["Вывести список отделов", view.show_departments],
    2: ["Вывести список всех сотрудников", view.show_employees],
    3: ["Вывести список сотрудников отдела", view.show_employees_in_departments],
    4: ["Добавить отдел", view.input_department, models.add_department],
    5: ["Добавить сотрудника", view.input_employee, models.add_employee],
    6: ["Перемести сотрудника в другой отдел", view.input_new_department_in_employee, models.change_departments_in_employee],
    7: ["Уволить сотрудника", ...],
    # 8: ["Экспорт отделов в csv", ...],
    0: ["Выйти из программы", exit]
}